package com.example.mobile
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.TextView

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val buttonShowMessage = findViewById<Button>(R.id.button_show_message)
        val textMessage = findViewById<TextView>(R.id.text_message)

        buttonShowMessage.setOnClickListener {
            // Show static message
            textMessage.text = "Hello! This is your static message."
            textMessage.visibility = View.VISIBLE
        }
    }
}
