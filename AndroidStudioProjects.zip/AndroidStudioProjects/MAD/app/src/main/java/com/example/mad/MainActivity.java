package com.example.mad;


import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View; // Import View for OnClickListener
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    // Declare the views at the class level so they can be accessed by the listener
    private Button showMessageButton;
    private TextView messageTextView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main); // This links your Java file to the XML layout

        // Get references to the Button and TextView from the layout
        showMessageButton = findViewById(R.id.showMessageButton);
        messageTextView = findViewById(R.id.messageTextView);

        // Set an OnClickListener for the button
        showMessageButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Action to perform when the button is clicked
                messageTextView.setText("Hello! This is your static message from Java.");
            }
        });
    }
}